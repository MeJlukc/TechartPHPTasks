<?php
require ROOT . "/DB.php";

class News
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function getCount()
    {
        $sql = "
            SELECT count(*) total
            FROM news
        ";
        
        // $rs = $this->db->query($sql);
        $rs = DB::getConnection();
        $rs->query($sql);
        $row = $rs->fetch();
        
        return $row['total'];
    }

    public function getList($limit, $offset)
    {
        $sql = "
            SELECT *,
            DATE_FORMAT(`date`, '%d.%m.%Y') fmt
            FROM news
            ORDER BY `date` DESC
            LIMIT :limit OFFSET :offset
        ";
        
        $rs = $this->db->prepare($sql);
        $rs->bindValue(":limit", $limit, PDO::PARAM_INT);
        $rs->bindValue(":offset", $offset, PDO::PARAM_INT);
        $rs->execute();

        return $rs->fetchAll();
    }

    public function findNews($id)
    {
        $sql = "
            SELECT *,
            DATE_FORMAT(`date`, '%d.%m.%Y') fmt
            FROM news
            WHERE id = :id
        ";

        $rs = $this->db->prepare($sql);
        $rs->bindValue(':id', $id, PDO::PARAM_INT);
        $rs->execute();

        return $rs->fetch();
    }

    public function getLastOne()
    {
        $sql = "
            SELECT *,
            DATE_FORMAT(`date`, '%d.%m.%Y') fmt
            FROM news
            ORDER BY `date` DESC
            LIMIT 1
        ";

        $rs = $this->db->query($sql);
        
        return $rs->fetch();
    }
}
