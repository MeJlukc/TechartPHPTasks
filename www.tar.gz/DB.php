<?php
// require ROOT . "/dbconfig.php";

class DB
{
    public static function getConnection()
    {
        // временное решение
        $host = 'localhost';
        $dbname = 'workspace__test';
        $user = 'root';
        $password = 'root';

        return new PDO(
            "mysql:host=$host;dbname=$dbname;charset=utf8", 
            $user, 
            $password
        );
    }
}
