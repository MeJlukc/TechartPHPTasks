<?php
$host = 'localhost';
$dbname = 'workspace__test';
$user = 'root';
$password = 'root';

$db = new PDO(
    "mysql:host=$host;dbname=$dbname;charset=utf8", 
    $user, 
    $password
);
